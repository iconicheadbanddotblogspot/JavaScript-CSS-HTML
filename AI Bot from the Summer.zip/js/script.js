// Write JavaScript herevar questionNum = 0;													// keep count of question, used for IF condition.
var question = '<h1>what is your name?</h1>';				  // first question

var output = document.getElementById('output');				// store id="output" in output variable
output.innerHTML = question;													// ouput first question

function bot() { 
    var input = document.getElementById("input").value;
    console.log(input);   //this is where you enter age

    if (questionNum == 0) {
    output.innerHTML = '<h1>hello ' + input + '</h1>';// output response
    document.getElementById("input").value = "";   		// clear text box
    question = '<h1>how old are you?</h1>';			    	// load next question		
    setTimeout(timedQuestion, 3000);									// output next question after 2sec delay
    }

    else if (questionNum == 1){
			var birthYear = 2018 - input;
			if(birthYear >= 2001){
				output.innerHTML = '<h1> That means you are a 2000s baby. gross.</h1>'
			} else if(birthYear >= 1990 && birthYear <= 1999){
					output.innerHTML = '<h1> That means you are a 90s baby. nice.</h1>'
				} else if(birthYear >= 1980 && birthYear <= 1989){
					output.innerHTML = '<h1> That means you were alive during the crack era.</h1>'
				} else if(birthYear >= 1970 && birthYear <= 1979){
					output.innerHTML = '<h1> That means you were probably alive when Ali beat the shit out of Joe Frazier</h1>'
				}
   // output.innerHTML = '<h1>That means you were born in ' + birthYear + '</h1>';
    document.getElementById("input").value = "";   
    question = '<h1>where are you from?</h1>';					      	
    setTimeout(timedQuestion, 3000);
    }
	
	else if (questionNum == 2){
		output.innerHTML = '<h1> Thats one of my favourite states</h1>';
		document.getElementById("input").value = "";
		question = '<h1> does this even work? yes or no?</h1>';
		setTimeout(timedQuestion, 3000);
	 }
	
	else if (questionNum == 3){
		if(input == "yes"){
			output.innerHTML = '<h1>thats crazy, I thought this shit was broken.</h1>';
		}
	else if (input == "no"){
		output.innerHTML = '<h1>its expected, I was made by a shit developer so...</h1>';
	 }
		document.getElementById("input").value = "";
		question = '<h2> green, red, purple, orange, pink, or yellow?</h2>';
		setTimeout(timedQuestion, 3000);
	}
  
	else if(questionNum == 4){
	 if(input == "green" || input == "Green" || input == "GREEN"){
		 output.innerHTML = '<h1 style="color:green;"> I hope this shit changed</h1>';
	 } else if(input == "orange" || input == "Orange" || input == "ORANGE"){
     output.innerHTML = '<h1 style="color:orange;"> I hope this shit changed</h1>';
   } else if(input == "purple" || input == "Purple" || input == "PURPLE"){
     output.innerHTML = '<h1 style="color:purple;"> I hope this shit changed</h1>';
   } else if(input == "yellow" || input == "Yellow" || input == "YELLOW"){
     output.innerHTML = '<h1 style="color:yellow;"> I hope this shit changed</h1>';
   } else if(input == "red" || input == "Red" || input == "RED"){
     output.innerHTML = '<h1 style="color:red;"> I hope this shit changed</h1>';
   } else if(input == "pink" || input == "Pink" || input == "PINK"){
     output.innerHTML = '<h1 style="color:pink;"> I hope this shit changed</h1>';
     }
    document.getElementById("input").value = "";
    question = '<h1> I didnt like the color, I changed it back. You want to play 21 questions?</h1>';
    setTimeout(timedQuestion, 3000);
		}
  
  else if(questionNum == 5){
    if(input == "yes" || input == "Yes" || input || "YES"){
      output.innerHTML = '<h1> fuck all this shit.</h1>';
    }
    
    else if(input == "no" || input == "No" || input == "NO"){
      output.innerHTML = '<h1> well what do you want to talk about?</h1>'; 
    }
    document.getElementById("input").value = "";
     setTimeout(timedQuestion, 3000);
  }
}
  

function timedQuestion() {
    output.innerHTML = question;
}

//push enter key (using jquery), to run bot function.
$(document).keypress(function(e) {
  if (e.which == 13) {
    bot();																						// run bot function when enter key pressed
    questionNum++;																		// increase questionNum count by 1
  }
});
 